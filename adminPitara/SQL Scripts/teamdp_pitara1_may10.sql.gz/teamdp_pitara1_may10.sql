-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2014 at 05:09 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `teamdp_pitara1`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_details`
--

CREATE TABLE IF NOT EXISTS `category_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `seo_title` varchar(1000) NOT NULL,
  `seo_desc` varchar(1500) NOT NULL,
  `og_title` varchar(1000) NOT NULL,
  `og_desc` varchar(1500) NOT NULL,
  `short_desc` varchar(1500) NOT NULL,
  `long_desc` mediumtext NOT NULL,
  `image_url` varchar(1000) NOT NULL,
  `index_flag` int(11) NOT NULL,
  `url_slug` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `category_details`
--

INSERT INTO `category_details` (`id`, `name`, `title`, `description`, `seo_title`, `seo_desc`, `og_title`, `og_desc`, `short_desc`, `long_desc`, `image_url`, `index_flag`, `url_slug`) VALUES
(4, 'dsad asdas sad as', 'dd sad as', 'dsad asdas sad asdsad asdas sad as\n												    ', '', '', 'dd sad as', 'dsad asdas sad asdsad asdas sad as												    ', 'dasdas ads asd asd as', 'dsad asdas sad asdsad asdas sad asdsad asdas sad asdsad asdas sad as													\n												    ', '', 0, 'dd-sad-as'),
(5, 'test', 'tests seset', 'tests sesettests sesettests sesettests sesettests seset\n												    ', '', '', 'tests seset', 'tests sesettests sesettests sesettests sesettests seset												    ', 'tests sesettests sesettests sesettests seset', 'tests sesettests sesettests sesettests sesettests sesettests seset &nbsp;tests sesettests seset&nbsp;tests seset&nbsp;', '', 0, 'tests-seset');

-- --------------------------------------------------------

--
-- Table structure for table `category_mapping`
--

CREATE TABLE IF NOT EXISTS `category_mapping` (
  `deal_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_mapping`
--

INSERT INTO `category_mapping` (`deal_id`, `category_id`, `creation_date`) VALUES
(1, 5, '2014-05-08 18:19:30'),
(2, 5, '2014-05-10 03:52:19'),
(3, 5, '2014-05-10 03:53:10'),
(4, 5, '2014-05-10 03:59:00'),
(5, 5, '2014-05-10 04:02:59'),
(6, 5, '2014-05-10 04:12:59'),
(7, 5, '2014-05-10 04:15:14'),
(8, 5, '2014-05-10 04:15:44');

-- --------------------------------------------------------

--
-- Table structure for table `product_deals`
--

CREATE TABLE IF NOT EXISTS `product_deals` (
  `deal_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `seo_title` varchar(1000) NOT NULL,
  `seo_desc` varchar(1000) NOT NULL,
  `og_title` varchar(1000) NOT NULL,
  `og_desc` varchar(1000) NOT NULL,
  `image_url` varchar(1000) NOT NULL,
  `store_name` varchar(200) NOT NULL,
  `discount` int(11) NOT NULL,
  `coupon_code` varchar(200) NOT NULL,
  `expiry` varchar(200) NOT NULL,
  `shipping_charges` varchar(1000) NOT NULL,
  `content` mediumtext NOT NULL,
  `offer_text` varchar(500) NOT NULL,
  `affiliate_url` varchar(500) NOT NULL,
  `original_price` int(11) NOT NULL,
  `final_price` int(11) NOT NULL,
  `deal_weight` int(11) NOT NULL,
  `url_slug` varchar(1000) NOT NULL,
  `author` varchar(200) NOT NULL,
  `deal_flag` int(11) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`deal_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `product_deals`
--

INSERT INTO `product_deals` (`deal_id`, `title`, `description`, `seo_title`, `seo_desc`, `og_title`, `og_desc`, `image_url`, `store_name`, `discount`, `coupon_code`, `expiry`, `shipping_charges`, `content`, `offer_text`, `affiliate_url`, `original_price`, `final_price`, `deal_weight`, `url_slug`, `author`, `deal_flag`, `creation_date`) VALUES
(1, 'daasdsa', 'ddfs dsfds fsd dsf d', 'daasdsa', 'ddfs dsfds fsd dsf d', 'daasdsa', 'ddfs dsfds fsd dsf d', 'http://localhost/dealspitara/dpv2/adminPitara/deals_images/teststore.jpg', 'teststore', 14, '322dadaas', '13-05-2014', 'dsad dfds dssd', 'fsdf sdfsdfsd ds sdfsd&nbsp;', 'fd sdfsd dsf', 'fsd sdf dsfdf', 432, 213, 0, 'daasdsa', '1', 0, '2014-05-08 18:19:30'),
(2, 'dasdsa', 'dsadsaadasd dsa&nbsp;', 'dasdsa', 'dsadsaadasd dsa&nbsp;', 'dasdsa', 'dsadsaadasd dsa&nbsp;', '', 'teststore', 12, '132dfsfsf', '14-05-2014', '2321324v rfefsdfsfsd', 'sf sd fsdf sdsd &nbsp;sdds fds ds dsfsd dsf sdf ds', 'sfsdfsdfsdfsdf', 'sdfsdfsdfsd fsd fsdfsd ', 234, 123, 0, 'dasdsa', '1', 0, '2014-05-10 03:52:19'),
(3, 'dsaasd adas as', 'dasdsa sad sa asdsasad', 'dsaasd adas as', 'dasdsa sad sa asdsasad', 'dsaasd adas as', 'dasdsa sad sa asdsasad', '', 'teststore', 15, '4243fdfs', '12-05-2014', 'fsdfsdfsd', 'dfsdf sdfsd sdfsd sd s', 'fsdfsdfsdfsdf', 'sdfsdfsfsdfds ', 43, 42, 0, 'dsaasd-adas-as', '1', 0, '2014-05-10 03:53:10'),
(4, 'sadsada', 'dfsfdsf sdf sdsd dsf sd', 'sadsada', 'dfsfdsf sdf sdsd dsf sd', 'sadsada', 'dfsfdsf sdf sdsd dsf sd', '', 'teststore', 0, '', '', '', 'sdfdsf sf sddsf s', '', 'fsdfsdfsdfsd', 0, 0, 0, 'sadsada', '1', 0, '2014-05-10 03:59:00'),
(5, 'rtgdgdfgdfgd', 'gdfgdfgdfgdfgdfg', 'rtgdgdfgdfg', 'gdfgdfgdfgdfgdfg', 'rtgdgdfgdfg', 'gdfgdfgdfgdfgdfg', '', 'teststore', 0, '', '', '', 'gdfgdfgdfgfdgdf', '', 'gdgfg', 0, 0, 0, 'rtgdgdfgdfgd', '1', 0, '2014-05-10 04:02:59'),
(6, 'dfdss df sfsdds fds', 'df sdfsd ds sfsd fsd&nbsp;', 'dfdss df sfsdds fds', 'df sdfsd ds sfsd fsd&nbsp;', 'dfdss df sfsdds fds', 'df sdfsd ds sfsd fsd&nbsp;', '', 'teststore', 0, '', '', '', '&nbsp;sfdsf sd s fsd vxcv ngnvbncbv', '', 'fsdfs dfds fsfd', 0, 0, 0, 'dfdss-df-sfsdds-fds', '1', 0, '2014-05-10 04:12:58'),
(7, 'dsadasdasd', 'sdasdsdzcc', 'dsadasdasd', 'sdasdsdzcc', 'dsadasdasd', 'sdasdsdzcc', '', 'teststore', 0, '', '', '', 'xc zxc zc zcxz&nbsp;', '', 'cxzcxzcxzc', 0, 0, 0, 'dsadasdasd', '1', 0, '2014-05-10 04:15:14'),
(8, 'dasdasdnb', 'vxcvcxvxcvxcv', 'dasdasdnb', 'vxcvcxvxcvxcv', 'dasdasdnb', 'vxcvcxvxcvxcv', '', 'teststore', 0, '', '', '', 'fds fsdfsdf dsf s', '', 'fdsfsdfsdfsd', 0, 0, 0, 'dasdasdnb', '1', 0, '2014-05-10 04:15:44');

-- --------------------------------------------------------

--
-- Table structure for table `store_details`
--

CREATE TABLE IF NOT EXISTS `store_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `seo_title` varchar(1000) NOT NULL,
  `seo_desc` varchar(1500) NOT NULL,
  `og_title` varchar(1000) NOT NULL,
  `og_desc` varchar(1500) NOT NULL,
  `short_desc` varchar(1500) NOT NULL,
  `long_desc` mediumtext NOT NULL,
  `image_url` varchar(1000) NOT NULL,
  `index_flag` int(11) NOT NULL,
  `url_slug` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `store_details`
--

INSERT INTO `store_details` (`id`, `name`, `title`, `description`, `seo_title`, `seo_desc`, `og_title`, `og_desc`, `short_desc`, `long_desc`, `image_url`, `index_flag`, `url_slug`) VALUES
(1, 'teststore', '', '', '', '', '', '', '', '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `users_login`
--

CREATE TABLE IF NOT EXISTS `users_login` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `email_address` varchar(200) NOT NULL,
  `user_pass` varchar(500) NOT NULL,
  `user_level` int(11) NOT NULL,
  `last_loggedin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users_login`
--

INSERT INTO `users_login` (`user_id`, `user_name`, `email_address`, `user_pass`, `user_level`, `last_loggedin`) VALUES
(1, 'admin', 'yogi_prasad90@yahoo.com', '21232f297a57a5a743894a0e4a801fc3', 1, '2010-05-14 09:28:14'),
(2, 'yogi', 'yo@gmail.com', '938e14c074c45c62eb15cc05a6f36d79', 2, '2005-05-14 08:18:08'),
(3, 'xyz', 'xyz@gmail.com', 'd16fb36f0911f878998c136191af705e', 3, '2007-05-14 07:18:13'),
(4, 'yashwant', 'yashwant@gmail.com', 'b5bf3782c7cf59c5a8c3cda455e30b18', 2, '2005-05-14 13:53:08');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
